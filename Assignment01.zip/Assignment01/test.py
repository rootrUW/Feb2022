strData = input('Enter Data: ')
print('this is a test')
print(strData)


strMoreData = input('Enter More Data: ')

print(strData + ' ' + strMoreData)

